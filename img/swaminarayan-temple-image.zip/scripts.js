// let data=document.getElementById("navlist");
// function myFunction() {
//     // for (let i = 0; i < data.length; i++) {
//       data.classList.toggle("show");
//     // }
//   }
 
// const onclick = function(event) {
//     if (!event.target.matches('.dropbtn')) {
//       var dropdowns = document.getElementsByClassName("nav-list");
//       var i;
//       for (i = 0; i < dropdowns.length; i++) {
//         var openDropdown = dropdowns[i];
//         if (openDropdown.classList.contains('show')) {
//           openDropdown.classList.remove('show');
//         }
//       }
//     }
//   }


let manu = document.getElementById("navList");

function openmanu(){
  manu.style.right = '0';
}

function closemanu(){
  manu.style.right = '-200px';
}


window.addEventListener('scroll', function() {
    var navbar = document.getElementById('navbar');
    if (window.scrollY > 0) {
        // navbar.style.backgroundColor = 'rgba(2, 33, 0, 0.7)';
        navbar.style.background = "linear-gradient(to bottom, rgba(2, 33, 0, 0.8), rgba(7, 100, 1, 0.8))";

    } else {
        // navbar.style.backgroundColor = 'rgba(2, 33, 0, 0.8)';
        navbar.style.background = "linear-gradient(to bottom, rgba(2, 33, 0, 0.8), rgba(7, 100, 1, 0.8))";
    }
});

// function myFunction() {
//     var x = document.getElementById("navList");
//     if (x.className === "nav-list") {
//         x.className += " responsive";
//     } else {
//         x.className = "nav-list";
//     }
// }
